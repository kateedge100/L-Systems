#ifndef LSYSTEMS_H
#define LSYSTEMS_H

#include <iostream>




class LSystems
{
public:
    //Constructor
    LSystems();
    //Destructor
    ~LSystems();
    // Stores Rules
    void productions();
    //set axiom
    void setAxiom();
    void setAngle();
    void setRule();
    std::string getDrawingRule();
    std::string m_str;




private:
    void m_clear();
    std::string m_axiom;
    std::string m_alphabet;
    std::string m_axiomRule;
    std::string m_alphabetRule;

    std::string m_angle;
    int m_iterations;






};

#endif // LSYSTEMS_H
