#ifndef TURTLE_H
#define TURTLE_H

#include <iostream>
#include <math.h>



class Turtle
{
public:
    Turtle();
    void Draw();
    void rotateLeft();
    void rotateRight(int m_angle);
    void pitchUp(int m_angle);
    void pitchDown(int m_angle);
    void rollLeft(int m_angle);
    void rollRight(int m_angle);
    void position(float m_x,float m_y,float m_z);
    void orientation(float m_h,float m_l,float m_u);
    void push();
    void pop();


    // use Vec3 for direction and rotation

private:
    float m_x;
    float m_y;
    float m_z;
    float m_h;
    float m_l;
    float m_u;





};

#endif // TURTLE_H
