#ifndef SCENE_H
#define SCENE_H

#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>



class Scene
{
public:
    Scene();
    void init();
    void drawScene();



};

#endif // SCENE_H
