#include "turtle.h"
#include "branch.h"
#include "lsystems.h"
#include <GLFunctions.h>

Turtle::Turtle()
{

}

void Turtle::orientation(float m_h, float m_l, float m_u)
{
    // turtle starting orientation
    m_h=0;
    m_l=1;
    m_u=0;

    Vec4 orientation;
    // direction in space
    orientation.set(m_h,m_l,m_u,0.0f);


}

void Turtle::position(float m_x, float m_y, float m_z)
{
    //turtle starting position
    m_x=0.0;
    m_y=0.0;
    m_z=0.0;



    Vec4 position;

     // position in space
    position.set(m_x,m_y,m_z,1.0f);

}

void Turtle::rotateLeft()
{


   //Mat4 rotateU;

   //rotateU.set;

}


void Turtle::rotateRight(int m_angle)
{
    //glRotatef(45,1,0,0);


}


void Turtle::rollLeft(int m_angle)
{

}

void Turtle::rollRight(int m_angle)
{

}

void Turtle::pitchUp(int m_angle)
{
    //glRotatef(45,0,1,0);

}

void Turtle::pitchDown(int m_angle)
{
    //glRotatef(-45,0,1,0)

}


void Turtle::push()
{
   glPushMatrix();
}

void Turtle::pop()
{
   glPopMatrix();
}





void Turtle::Draw()
{

    LSystems l;
    //Sets drawingRule equil to final iteraltion of m_str
    std::string drawingRule = "FF+F"; // l.getDrawingRule();
    std::string currentChar = "";

    std::cout<<"Drawing Rule\n"<<drawingRule<<"\n";


      // begins comparing at beginning of string at each iteraion
      unsigned long i =0;

      //Go through each character until last character
      for(i =0; i<drawingRule.length();i++)
      {

          currentChar=drawingRule.at(i);


          std::cout<<drawingRule<<"\n";

          //Go through each character until last character
          while(i!= drawingRule.length())
          {
            currentChar=drawingRule.at(i);

            if(currentChar.compare("F") == 0)
            {
                Branch b;
                b.createBranch();
                std::cout<<"F Read\n";

            // jumps to next character
            i=i+1;
            }
            else if(currentChar.compare("+")== 0)
            {
                //rotateLeft();
                std::cout<<"rotated left\n";

              i=i+1;
            }
            else
            {
                i=i+1;
            }

          }


        }


}

