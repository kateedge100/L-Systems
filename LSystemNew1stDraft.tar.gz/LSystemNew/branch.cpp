#include "branch.h"





Branch::Branch()
{

}

void Branch::init()
{
    glFrontFace(GL_CCW);
    glDisable(GL_TEXTURE_2D);


    glEnable(GL_NORMALIZE);

    glEnable( GL_POINT_SMOOTH);
    glEnable( GL_MULTISAMPLE_ARB);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_POINT_SIZE);
    glPointSize(100);

}

void Branch::setLength()
{
    m_length=0.2;

}

void Branch::createBranch()
{

    //glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT)


    glPushMatrix();
    GLUquadricObj*qobj = gluNewQuadric();
    glTranslated(-0.2,0,-0.4);
    glRotatef(90,0.0f,1.0f,0.0f);
    glRotatef(90,1.0f,0.0f,0.0f);
    gluCylinder(qobj,
                0.01,
                0.012,
                0.5,
                50,
                50);
    //gluDeleteQuadric(qobj);

    //moves cylinder up each time drawn
    glTranslated(0,1,0);
    glPopMatrix();


/*
    glPushMatrix();
    GLUquadricObj*qobj = gluNewQuadric();
    glTranslated(-0.2,0,-0.4);
    glRotatef(90,0.0f,1.0f,0.0f);
    glRotatef(90,1.0f,0.0f,0.0f);
    gluCylinder(qobj,
                0.01,
                0.012,
                0.5,
                50,
                50);
    //gluDeleteQuadric(qobj);
    //glTranslated(0,0.75,0);
    glPopMatrix();

    */

    std::cout<<"branch drawn\n";



}


