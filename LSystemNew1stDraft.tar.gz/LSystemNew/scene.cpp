#include "scene.h"

Scene::Scene()
{

}

void Scene::init()
{
    // Enable texturing
    glDisable(GL_TEXTURE_2D);

    // Enable counter clockwise face ordering
    glFrontFace(GL_CCW);

    glEnable(GL_LIGHTING);
    glEnable(GL_NORMALIZE);


    // Make our points lovely and smooth
    glEnable( GL_POINT_SMOOTH );
    glEnable( GL_MULTISAMPLE_ARB);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_POINT_SIZE);
    glPointSize(100);




    // Set the background colour
    //glClearColor(1,0,0,0);


}

void Scene::drawScene()
{
      glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

}



