#include "lsystems.h"
#include "turtle.h"
#include <iostream>
#include <fstream>



LSystems::LSystems()
{

}

LSystems::~LSystems()
{

    m_str.clear();

}

void LSystems::setAxiom()
{
    std::ifstream inputAxiom("Axiom1.txt");

    std::getline(inputAxiom,m_axiom);

}

void LSystems::setAngle()
{
    std::ifstream inputAngle("Angle1.txt");
    std::getline(inputAngle,m_angle);

}


void LSystems::productions()
{

    m_axiom = "X";
    // assignes string axiom will be replaced with
    m_axiomRule = "F-[[X]+X]+F[+FX";

    m_alphabet = "F";
    m_alphabetRule = "FF";

    int axRuleLength= m_axiomRule.length();
    int alRuleLength = m_alphabetRule.length();



    //creates string to store rule
    m_str = "";
    // creates string to access each character in str
    std::string m_ch = "";
    // inserts axiom into rule
    m_str.insert(0,m_axiom);

    //prints axiom
    std::cout<<"axiom\n"<<m_str<< "\n";

    // number of iterations
     m_iterations = 3;

  // reference https://github.com/paluka/L-Systems-OpenGL/blob/master/src/Paluka-L-System.cpp

  // iteration rule to number of iterations
  for(int n=1;n<=m_iterations;n++)
  {

    std::cout<<"iteration "<<n<<""<<std::endl;
    // begins comparing at beginning of string at each iteraion
    unsigned long i =0;

    //Go through each character until last character
    while(i!= m_str.length())
    {
      m_ch=m_str.at(i);

      if(m_ch.compare(m_axiom) == 0)
      {   // if current character is axiom replaces with axiomRule
      m_str.replace(i,1,m_axiomRule);
      // jumps to character after FXX (3 ahead) to compare
      i=i+axRuleLength;
      }
      else if(m_ch.compare(m_alphabet)== 0)
      {
        m_str.replace(i,1,m_alphabetRule);
        i=i+alRuleLength;
      }
      else
      {
          i=i+1;
      }


    }

    // prints updated string
    std::cout << m_str << "\n";

  }
}

std::string LSystems::getRule()
{
    // returns final version of string
    std::cout<<"printing final rule\n"<<m_str<<"\n";

    std::string Rule = m_str;
    return Rule;
}
